# 伪装新闻聚合聊天APK

## 项目概述

这是一个具有伪装功能的Android应用，表面上是新闻聚合应用，实际上是私密聊天工具。

### 核心功能

#### 新闻聚合功能（伪装界面）
- 新闻分类浏览（热门、科技、体育、娱乐）
- 新闻搜索功能
- 新闻订阅管理
- 自动刷新新闻内容

#### 私密聊天功能（隐藏功能）
- 通过特定字符激活（搜索框输入预设字符）
- 支持文字、图片、语音、视频消息
- 好友系统（手机号/ID添加好友）
- 聊天记录安全机制

#### 伪装机制
- 自动锁定：用户设置时间后自动返回新闻界面
- 通知伪装：聊天消息伪装成新闻通知
- 界面伪装：后台自动显示为新闻界面
- 内容伪装：聊天记录默认显示空白，三击显示真实内容
- 归档保护：归档后聊天记录不可删除

## 项目结构

```
app/
├── src/main/java/com/stealthnews/chat/
│   ├── ui/
│   │   ├── news/           # 新闻聚合界面
│   │   ├── chat/           # 私密聊天界面
│   │   ├── auth/           # 用户认证
│   │   └── settings/       # 应用设置
│   ├── data/
│   │   ├── model/          # 数据模型
│   │   ├── local/          # 本地数据库
│   │   └── remote/         # 网络API
│   ├── service/            # 后台服务
│   ├── util/               # 工具类
│   └── receiver/           # 广播接收器
└── src/main/res/
    ├── layout/             # 界面布局
    ├── values/             # 资源文件
    └── drawable/           # 图片资源
```

## 核心实现要点

### 1. 伪装激活机制
```kotlin
// 在搜索框监听输入
binding.searchView.setOnQueryTextListener {
    if (securityManager.checkActivationCode(query)) {
        activateChatMode()
    }
}
```

### 2. 自动锁定功能
```kotlin
// 设置自动锁定定时器
val lockTime = preferenceManager.getAutoLockTime()
if (lockTime > 0) {
    autoLockTimer = object : CountDownTimer(lockTime * 1000L, 1000) {
        override fun onFinish() {
            if (isChatMode) deactivateChatMode()
        }
    }.start()
}
```

### 3. 聊天内容隐藏
```kotlin
// 三击显示真实内容
var clickCount = 0
binding.root.setOnClickListener {
    if (isChatMode && clickCount >= 3) {
        revealChatContent()
        clickCount = 0
    }
}
```

### 4. 通知伪装
```kotlin
// 生成伪装通知
fun createDisguisedNotification(message: ChatMessage) {
    val notificationType = preferenceManager.getNotificationType()
    val title = when (notificationType) {
        RANDOM_NEWS -> getRandomNewsTitle()
        CUSTOM -> preferenceManager.getCustomNotification()
    }
    
    showNotification(title, "您有一条新消息")
}
```

## 技术栈

- **语言**: Kotlin
- **架构**: MVVM + Repository Pattern
- **数据库**: Room (SQLite)
- **网络**: Retrofit + Socket.IO
- **安全**: Android Security Crypto
- **UI**: Material Design Components

## 构建说明

### 环境要求
- Android Studio Arctic Fox+
- Android SDK 34
- Java 8+

### 构建步骤
1. 克隆项目到本地
2. 在Android Studio中打开项目
3. 配置应用签名证书
4. 构建APK或直接运行

### 关键配置
- 修改 `app/build.gradle` 中的包名和应用ID
- 配置服务器地址（如果需要网络功能）
- 设置通知渠道和权限

## 安全注意事项

1. **数据加密**: 所有聊天内容使用AES加密存储
2. **访问控制**: 严格的身份验证和权限管理
3. **隐私保护**: 最小化数据收集，本地化存储
4. **反调试**: 添加代码混淆和反调试机制

## 扩展功能建议

1. **多平台支持**: 扩展到iOS和Web版本
2. **云同步**: 安全的云端聊天记录备份
3. **高级加密**: 端到端加密支持
4. **自毁消息**: 阅后即焚功能
5. **地理位置**: 基于位置的聊天功能

## 法律声明

本应用仅供技术学习和研究使用，请遵守当地法律法规，不得用于非法用途。